# Deploying to Vercel

This is now a real Vite + React project (not just a loose component file),
so Vercel can actually build and serve it.

## Easiest path: GitHub → Vercel import

1. Create a new repo on GitHub (github.com → New repository).
2. Upload all files in this folder to that repo, keeping the folder
   structure (`src/App.jsx`, `src/main.jsx`, `index.html`, `package.json`,
   `vite.config.js`).
3. In Vercel: **Add New → Project → Import** that GitHub repo.
4. Vercel auto-detects Vite. Leave build settings as default
   (`npm run build`, output dir `dist`). Deploy.

## If you have a computer with terminal access

```
npm install
npm run dev        # test locally first at http://localhost:5173
vercel              # deploy (installs Vercel CLI if needed, follow prompts)
```

## After it's live

Open the deployed URL, go to Settings, switch to "AI voice", and paste in
your Cloudflare Worker URL from DEPLOY-AI-VOICE.md. Everything else
(resume position, pronunciation dictionary) now persists in the browser's
localStorage on whatever device you're using it from.
